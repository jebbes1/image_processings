import os
from flask import Flask, request, render_template, redirect, url_for, flash
from PyPDF2 import PdfReader
from docx import Document
import cv2
import numpy as np

app = Flask(__name__)
app.secret_key = "secret_key"
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def checklist():
    return render_template('checklist.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        flash('No file part')
        return redirect(request.url)
    
    file = request.files['file']
    if file.filename == '':
        flash('No selected file')
        return redirect(request.url)

    file_path = os.path.join(app.config['UPLOAD_FOLDER'], "temp_" + file.filename)
    file.save(file_path)

    if file.filename.endswith(('.jpg', '.jpeg', '.png')):
        return handle_image_upload(file_path)
    
    elif file.filename.endswith('.pdf'):
        return handle_pdf_upload(file_path)
    
    elif file.filename.endswith('.docx'):
        return handle_docx_upload(file_path)
    
    else:
        os.remove(file_path)
        flash('Unsupported file type.')
        return redirect(url_for('checklist'))

def handle_image_upload(file_path):
    if validate_image(file_path):
        flash('Image uploaded successfully!')
        return redirect(url_for('checklist'))
    else:
        os.remove(file_path)
        flash('Image validation failed.')
        return redirect(url_for('checklist'))

def handle_pdf_upload(file_path):
    if validate_pdf(file_path):
        flash('PDF uploaded successfully!')
        return redirect(url_for('checklist'))
    else:
        os.remove(file_path)
        flash('PDF validation failed.')
        return redirect(url_for('checklist'))

def handle_docx_upload(file_path):
    if validate_docx(file_path):
        flash('Word document uploaded successfully!')
        return redirect(url_for('checklist'))
    else:
        os.remove(file_path)
        flash('Word document validation failed.')
        return redirect(url_for('checklist'))

def validate_image(file_path):
    image = cv2.imread(file_path)
    if image is None:
        return False
    height, width, _ = image.shape
    logo_region = image[:50, :100] 
    if np.mean(logo_region) < 50:
        return False
    header_region = image[:100, :]
    if np.mean(header_region) < 50:
        return False
    footer_region = image[-100:, :]
    if np.mean(footer_region) < 50:
        return False
    return True

def validate_pdf(file_path):
    try:
        reader = PdfReader(file_path)
        text = ""
        for page in reader.pages:
            text += page.extract_text()
        if "Logo" in text and "Header" in text and "Footer" in text:
            return True
    except Exception as e:
        print(e)
    return False

def validate_docx(file_path):
    try:
        doc = Document(file_path)
        text = ""
        for paragraph in doc.paragraphs:
            text += paragraph.text
        if "Logo" in text and "Header" in text and "Footer" in text:
            return True
    except Exception as e:
        print(e)
    return False

if __name__ == '__main__':
    app.run(debug=True)
